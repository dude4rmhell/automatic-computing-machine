$ErrorActionPreference = "Stop"

$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$pythonExe = Join-Path $projectRoot ".venv\Scripts\python.exe"

if (-not (Test-Path $pythonExe)) {
    throw "Virtual environment Python not found at $pythonExe"
}

$runningApps = Get-Process -Name "SubscriptionManager" -ErrorAction SilentlyContinue
foreach ($app in $runningApps) {
    Stop-Process -Id $app.Id -Force
}

$portUsers = Get-NetTCPConnection -LocalPort 8000 -ErrorAction SilentlyContinue |
    Select-Object -ExpandProperty OwningProcess -Unique
foreach ($processId in $portUsers) {
    $process = Get-Process -Id $processId -ErrorAction SilentlyContinue
    if ($process -and $process.Path -like "$projectRoot*") {
        Stop-Process -Id $processId -Force
    }
}

& $pythonExe -m PyInstaller `
  --noconfirm `
  --clean `
  --console `
  --name SubscriptionManager `
  --add-data "app\templates;app\templates" `
  launcher.py

Write-Host ""
Write-Host "Build complete."
Write-Host "EXE folder: $projectRoot\dist\SubscriptionManager"
