from datetime import date, datetime
from decimal import Decimal

from pydantic import BaseModel, ConfigDict, Field


class SubscriptionBase(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    provider: str | None = Field(default=None, max_length=200)
    category: str = Field(default="Uncategorized", max_length=100)
    amount: Decimal = Field(gt=0)
    currency: str = Field(default="USD", max_length=10)
    billing_cycle: str = Field(default="monthly", max_length=20)
    renewal_date: date | None = None
    payment_method: str | None = Field(default=None, max_length=100)
    status: str = Field(default="active", max_length=20)
    auto_renew: bool = True
    reminder_days: int = Field(default=7, ge=0)
    notes: str | None = None


class SubscriptionCreate(SubscriptionBase):
    pass


class SubscriptionRead(SubscriptionBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    created_at: datetime
    updated_at: datetime


class DashboardSummary(BaseModel):
    total_subscriptions: int
    active_subscriptions: int
    monthly_spend: Decimal
    yearly_spend: Decimal
    upcoming_renewals_30_days: int
