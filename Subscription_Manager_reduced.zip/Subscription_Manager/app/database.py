from pathlib import Path

from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

from app.paths import get_base_dir

BASE_DIR = get_base_dir()
DATA_DIR = BASE_DIR / "data"
DATABASE_PATH = DATA_DIR / "subscriptions.db"
DATABASE_URL = f"sqlite:///{DATABASE_PATH.as_posix()}"

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False},
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def init_db() -> None:
    from app import models  # noqa: F401

    DATA_DIR.mkdir(exist_ok=True)

    Base.metadata.create_all(bind=engine)
