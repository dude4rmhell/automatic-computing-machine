from sqlalchemy.orm import Session
from sqlalchemy import case, func
from datetime import date, timedelta

from app import models, schemas


def create_subscription(db: Session, subscription: schemas.SubscriptionCreate) -> models.Subscription:
    db_subscription = models.Subscription(**subscription.model_dump())
    db.add(db_subscription)
    db.commit()
    db.refresh(db_subscription)
    return db_subscription


def get_subscriptions(db: Session) -> list[models.Subscription]:
    return db.query(models.Subscription).order_by(models.Subscription.id.desc()).all()


def get_dashboard_summary(db: Session) -> schemas.DashboardSummary:
    today = date.today()
    upcoming_cutoff = today + timedelta(days=30)

    total_subscriptions = db.query(func.count(models.Subscription.id)).scalar() or 0
    active_subscriptions = (
        db.query(func.count(models.Subscription.id))
        .filter(models.Subscription.status == "active")
        .scalar()
        or 0
    )
    monthly_spend = (
        db.query(
            func.coalesce(
                func.sum(
                    case(
                        (models.Subscription.billing_cycle.ilike("year%"), models.Subscription.amount / 12),
                        else_=models.Subscription.amount,
                    )
                ),
                0,
            )
        )
        .scalar()
        or 0
    )
    yearly_spend = (
        db.query(
            func.coalesce(
                func.sum(
                    case(
                        (models.Subscription.billing_cycle.ilike("month%"), models.Subscription.amount * 12),
                        else_=models.Subscription.amount,
                    )
                ),
                0,
            )
        )
        .scalar()
        or 0
    )
    upcoming_renewals_30_days = (
        db.query(func.count(models.Subscription.id))
        .filter(models.Subscription.renewal_date.isnot(None))
        .filter(models.Subscription.renewal_date >= today)
        .filter(models.Subscription.renewal_date <= upcoming_cutoff)
        .scalar()
        or 0
    )

    return schemas.DashboardSummary(
        total_subscriptions=total_subscriptions,
        active_subscriptions=active_subscriptions,
        monthly_spend=monthly_spend,
        yearly_spend=yearly_spend,
        upcoming_renewals_30_days=upcoming_renewals_30_days,
    )
