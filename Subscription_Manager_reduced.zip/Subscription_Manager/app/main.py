from contextlib import asynccontextmanager
from datetime import date
from decimal import Decimal
from pathlib import Path
import sys

from fastapi import FastAPI, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates

# Allow `python app/main.py` to work from the project root.
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from app.database import init_db
from app import crud, database, schemas
from app.paths import get_resource_dir
from app.routers import subscriptions


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield

app = FastAPI(title="Subscription Manager", lifespan=lifespan)
app.include_router(subscriptions.router)
templates = Jinja2Templates(directory=str(get_resource_dir() / "app" / "templates"))


@app.post("/", response_class=RedirectResponse)
def create_subscription_form(
    name: str = Form(...),
    provider: str | None = Form(None),
    category: str = Form("Uncategorized"),
    amount: str = Form(...),
    currency: str = Form("USD"),
    billing_cycle: str = Form("monthly"),
    renewal_date: date | None = Form(None),
    payment_method: str | None = Form(None),
    status: str = Form("active"),
    auto_renew: str | None = Form(None),
    reminder_days: int = Form(7),
    notes: str | None = Form(None),
) -> RedirectResponse:
    db = database.SessionLocal()
    try:
        subscription_data = schemas.SubscriptionCreate(
            name=name,
            provider=provider or None,
            category=category,
            amount=Decimal(amount),
            currency=currency,
            billing_cycle=billing_cycle,
            renewal_date=renewal_date or None,
            payment_method=payment_method or None,
            status=status,
            auto_renew=auto_renew is not None,
            reminder_days=reminder_days,
            notes=notes or None,
        )
        crud.create_subscription(db, subscription_data)
    finally:
        db.close()

    return RedirectResponse(url="/", status_code=303)


@app.get("/", response_class=HTMLResponse)
def root(request: Request) -> HTMLResponse:
    db = database.SessionLocal()
    try:
        subscription_rows = crud.get_subscriptions(db)
        summary = crud.get_dashboard_summary(db)
    finally:
        db.close()

    subscriptions_data = []
    for row in subscription_rows:
        monthly_cost = row.amount if row.billing_cycle.lower().startswith("month") else row.amount / Decimal(12)
        subscriptions_data.append(
            {
                "name": row.name,
                "provider": row.provider or "Unknown provider",
                "category": row.category,
                "amount": f"{row.amount:.2f}",
                "billing_cycle": row.billing_cycle.title(),
                "renewal_date": row.renewal_date.isoformat() if row.renewal_date is not None else "Not set",
                "status": row.status.title(),
                "monthly_cost": f"{monthly_cost:.2f}",
            }
        )

    return templates.TemplateResponse(
        request,
        "index.html",
        context={
            "request": request,
            "summary": {
                "total_subscriptions": summary.total_subscriptions,
                "active_subscriptions": summary.active_subscriptions,
                "monthly_spend": f"{summary.monthly_spend:.2f}",
                "yearly_spend": f"{summary.yearly_spend:.2f}",
                "upcoming_renewals_30_days": summary.upcoming_renewals_30_days,
            },
            "subscriptions": subscriptions_data,
        },
    )


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, reload=True)
