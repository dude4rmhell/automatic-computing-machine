from sqlalchemy import Boolean, Column, Date, DateTime, Integer, Numeric, String, Text, func

from app.database import Base


class Subscription(Base):
    __tablename__ = "subscriptions"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(200), nullable=False, index=True)
    provider = Column(String(200), nullable=True)
    category = Column(String(100), nullable=False, default="Uncategorized")
    amount = Column(Numeric(10, 2), nullable=False)
    currency = Column(String(10), nullable=False, default="USD")
    billing_cycle = Column(String(20), nullable=False, default="monthly")
    renewal_date = Column(Date, nullable=True)
    payment_method = Column(String(100), nullable=True)
    status = Column(String(20), nullable=False, default="active")
    auto_renew = Column(Boolean, nullable=False, default=True)
    reminder_days = Column(Integer, nullable=False, default=7)
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime, server_default=func.now(), nullable=False)
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now(), nullable=False)

