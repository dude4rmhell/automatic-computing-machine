# Subscription Manager

FastAPI-based subscription tracker with a browser UI and local SQLite storage.

## Run locally

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open `http://127.0.0.1:8000/` in your browser.

## Build a Windows EXE

The app can be packaged as a desktop launcher that starts the local server and opens the browser automatically.

```powershell
.\build_exe.ps1
```

After the build finishes, run:

```powershell
.\dist\SubscriptionManager\SubscriptionManager.exe
```
