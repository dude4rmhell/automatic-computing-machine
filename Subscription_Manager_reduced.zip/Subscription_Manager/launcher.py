import threading
import time
import webbrowser
from pathlib import Path
import sys

import uvicorn

from app.main import app


LOG_FILE = Path(sys.executable).resolve().parent / "SubscriptionManager.log"

LOG_CONFIG = {
    "version": 1,
    "disable_existing_loggers": False,
    "handlers": {
        "file": {
            "class": "logging.FileHandler",
            "filename": str(LOG_FILE),
            "formatter": "default",
            "encoding": "utf-8",
        },
    },
    "formatters": {
        "default": {
            "format": "%(asctime)s %(levelname)s %(name)s: %(message)s",
        },
    },
    "loggers": {
        "uvicorn": {"handlers": ["file"], "level": "INFO", "propagate": False},
        "uvicorn.error": {"handlers": ["file"], "level": "INFO", "propagate": False},
        "uvicorn.access": {"handlers": ["file"], "level": "INFO", "propagate": False},
    },
}


def open_browser() -> None:
    time.sleep(1.5)
    webbrowser.open("http://127.0.0.1:8000/")


def main() -> None:
    threading.Thread(target=open_browser, daemon=True).start()
    uvicorn.run(
        app,
        host="127.0.0.1",
        port=8000,
        reload=False,
        log_config=LOG_CONFIG,
        access_log=False,
    )


if __name__ == "__main__":
    main()
